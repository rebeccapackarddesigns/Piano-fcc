# Piano  FCC Project

A Pen created on CodePen.io. Original URL: [https://codepen.io/rebeccapackarddesigns/pen/mdXNXwN](https://codepen.io/rebeccapackarddesigns/pen/mdXNXwN).

